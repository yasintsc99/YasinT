﻿/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** ÖDEV NUMARASI..........: 1
** ÖĞRENCİ ADI............: YASİN TAŞCI
** ÖĞRENCİ NUMARASI.......: B181200021
** DERSİN ALINDIĞI GRUP...: A
****************************************************************************/
using System;

namespace NDP
{
    class Program
    {
        static void Main(string[] args)
        {
            //Arkaplan rengi ve yazı rengi ayarlandı.
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.Clear();
            Console.WriteLine("                                    Apartman Yönetimi Uygulamamıza Hoşgeldiniz...");
            string secim="";
            //1 Apartman 10 daire türetildi.
            Apartman apartman = new Apartman();
            Daire daire1 = new Daire("Halil Koçak", "1");
            Daire daire2 = new Daire("Mert Sönmez", "2");
            Daire daire3 = new Daire("Elif Akarsu", "3");
            Daire daire4 = new Daire("Ayşe Sağlam", "4");
            Daire daire5 = new Daire("Yasin Taşcı", "5");
            Daire daire6 = new Daire("Salih Irmak", "6");
            Daire daire7 = new Daire("Melih Barlas", "7");
            Daire daire8 = new Daire("Semiha Öner", "8");
            Daire daire9 = new Daire("Hasan Tekin", "9");
            Daire daire10 = new Daire("Arslan Ekşi", "10");
            Daire[] daireler ={daire1, daire2, daire3, daire4, daire5, daire6, daire7, daire8, daire9, daire10};
            //Apartman sakinlerinin adsoyad ve daire numaraları bilgisiyle aidat ödeme durumunu yazdıran fonksiyon
            void Aidat_Bilgileri()
            {
                //daireler dizisinin uzunluğu boyunca devam eden döngü
                for(int i=0; i<daireler.Length; i++)
                {
                    string aidat;
                    //İlgili dairenin borcu 0 sa aidat değişkenini "Ödendi" değilse "Eksik / Ödenmedi" ataması yapar.
                    if (daireler[i].Borc == 0)
                        aidat = "Ödendi";
                    else aidat = "Eksik / Ödenmedi";
                    //İlgili alanları yazdırır.
                    Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\n", daireler[i].Dairesahibi, daireler[i].Daireno, daireler[i].odenen_tutar, aidat);
                }
            }
                //Apartman gelirini ödenen aidat miktarınca arttıran döngü
                for(int i=0; i<daireler.Length;i++)
                {
                    apartman.Gelir += daireler[i].odenen_tutar;
                }
             
            while(true)
            {
                Console.WriteLine(" \nLütfen Yapmak istediğiniz işlemi seçiniz...");
                Console.WriteLine("\t1-Aidat Takibi");
                Console.WriteLine("\t2-Borç Sorgulama");
                Console.WriteLine("\t3-Apartman Gelir-Gider Durumu");
                Console.WriteLine("\t4-Gelir Girişi");
                Console.WriteLine("\t5-Gider Girişi");
                Console.WriteLine("\t6-Çıkış");
                secim = Console.ReadLine();
                switch (secim)
                {
                    //Aidat Takibi seçilirse yapılacaklar
                    case "1":
                        {
                            //Aidat_Bilgileri fonksiyonundaki ilgili veriyi yazdırır.
                            Console.Clear();
                            Console.WriteLine("-----------       AİDAT TAKİP SİSTEMİ         -------------\n");
                            Console.WriteLine(" Daire Sahibi\tDaire No\tÖdenen Tutar\tAidat\n");
                            Aidat_Bilgileri();
                            break;
                        }
                        //Borç Sorgulama seçilirse yapılacaklar
                    case "2":
                        {
                            Console.Clear();
                            Console.WriteLine("-----------       BORÇ SORGULAMA EKRANI         -------------\n");
                            Console.Write(" DAİRE NO : ");
                            string daire = Console.ReadLine();
                            int i = 0;
                            //Daire arama işlemini yapar.
                            while (!daireler[i].Daireno.Equals(daire))
                            {
                                i++;
                            }
                            //Aranan dairenin sahibine ait adsoyad ve borc bilgilerini yazdırır.
                            Console.WriteLine(" DAİRE SAHİBİ\tBORÇ TUTARI");
                            Console.WriteLine(" {0}\t{1}", daireler[i].Dairesahibi, daireler[i].Borc);
                        }
                        break;
                        //Apartman Gelir-Gider Durumu seçilirse yapılacaklar
                    case "3":
                        {
                            Console.Clear();
                            //Apartman gelir-gider farkı 0'dan büyükse karda değilse zararda yazdırır.
                            Console.WriteLine("----------         APARTMAN GELİR-GİDER DURUMU          -----------");
                            if (apartman.Gelir-apartman.Gider > 0)
                                Console.Write("\n Apartman {0} TL Karda ...", apartman.Gelir - apartman.Gider);
                            else
                                Console.Write("\n Apartman {0} TL Zararda ...", apartman.Gelir - apartman.Gider);
                        }
                        break;
                        //Gelir girişi seçilirse yapılacaklar
                    case "4":
                        {
                            Console.Clear();
                            Console.WriteLine("----------         GELİR GİRİŞİ          -----------\n");
                            Console.Write(" GELİR TÜRÜ : ");
                            Console.ReadLine();
                            Console.Write(" \n GELİR TUTARI : ");
                            //Apartman geliri girilen veri kadar arttırılır.
                            apartman.Gelir += int.Parse(Console.ReadLine());
                            //En son apartmanın güncel gelir-gider durumu yazdırılır.
                            Console.WriteLine(" \n--------     APARTMANIN GÜNCEL GELİR-GİDER TABLOSU     ------------");
                            Console.Write(" \nGELİRLER : {0} TL \t GİDERLER : {1} TL", apartman.Gelir, apartman.Gider);
                        }
                        break;
                        //Gider girişi seçilirse yapılacaklar
                    case "5":
                        {
                            Console.Clear();
                            Console.WriteLine("----------         GİDER GİRİŞİ          -----------\n");
                            Console.Write(" GİDER TÜRÜ : ");
                            Console.ReadLine();
                            Console.Write(" \nGİDER TUTARI : ");
                            //Apartman gideri girilen veri kadar arttırılır.
                            apartman.Gider += Convert.ToInt32(Console.ReadLine());
                            //En son apartmanın güncel gelir-gider durumu yazdırılır.
                            Console.WriteLine(" \n--------     APARTMANIN GÜNCEL GELİR-GİDER TABLOSU     ------------");
                            Console.Write(" \nGELİRLER : {0} TL \t GİDERLER : {1} TL", apartman.Gelir,apartman.Gider);
                        }
                        break;
                        //Çıkış seçeneği seçilirse uygulama kapatılır.
                    case "6": Environment.Exit(0); break;
                        //Var olan seçenekler dışında seçim yapılmaya çalışılırsa yapılacaklar
                    default: Console.WriteLine("Yanlış Seçim Yaptınız Tekrar Deneyiniz..."); break;
                }
            }
        }
    }
}
