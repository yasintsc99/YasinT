﻿
/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** ÖDEV NUMARASI..........: 1
** ÖĞRENCİ ADI............: YASİN TAŞCI
** ÖĞRENCİ NUMARASI.......: B181200021
** DERSİN ALINDIĞI GRUP...: A
****************************************************************************/
using System;
using System.Collections.Generic;
using System.Text;

namespace NDP
{
    public class Apartman
    {
        //İlgili alanlar oluşturuldu.
        protected int aidat=50;
        public int Gider;
        public int Gelir;    
        //Kurucu fonksiyonda gider değişkene 0-100 arası rastgele olarak belirlendi.
        public Apartman()
        {
            Gider = new Random().Next(0, 11) * 10;
        }
        //Apartmanın gelir-gider durumunu gösterecek fonksiyon yazıldı.
        public int Gelir_Gider_Durumu()
        {
            return Gelir - Gider;
        }
    }
}
