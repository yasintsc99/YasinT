﻿/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** ÖDEV NUMARASI..........: 1
** ÖĞRENCİ ADI............: YASİN TAŞCI
** ÖĞRENCİ NUMARASI.......: B181200021
** DERSİN ALINDIĞI GRUP...: A
****************************************************************************/
using System;
using System.Collections.Generic;
using System.Text;

namespace NDP
{
    public class Daire:Apartman
    {
        //İlgili alanlar oluşturuldu.
        public string Dairesahibi;
        public string Daireno;
        public int Borc;
        public int odenen_tutar;
        //Daire sahibinin adı ve soyadıyla daire no sunu parametre alan kurucu fonksiyon
        public Daire(string dairesahibi,string daireno)
        {
            //Daire sahibinin ödeyeceği miktar 0 ile 50 arasında belirlendi ve ilgili atamalar yapıldı.
            odenen_tutar = new Random().Next(0,6) * 10;
            Dairesahibi = dairesahibi;
            Daireno = daireno;
            Borc = aidat - odenen_tutar;
        }
       
    }
}
