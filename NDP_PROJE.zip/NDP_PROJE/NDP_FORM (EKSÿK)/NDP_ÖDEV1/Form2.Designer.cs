﻿namespace NDP_ÖDEV1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.Uygulama_baslik = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.daire_No = new System.Windows.Forms.ComboBox();
            this.bitis_tarihi = new System.Windows.Forms.DateTimePicker();
            this.baslangıc_tarihi = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.access = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Geri = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Uygulama_baslik
            // 
            this.Uygulama_baslik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Uygulama_baslik.AutoSize = true;
            this.Uygulama_baslik.BackColor = System.Drawing.Color.Transparent;
            this.Uygulama_baslik.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Uygulama_baslik.Location = new System.Drawing.Point(234, 29);
            this.Uygulama_baslik.Name = "Uygulama_baslik";
            this.Uygulama_baslik.Size = new System.Drawing.Size(350, 29);
            this.Uygulama_baslik.TabIndex = 1;
            this.Uygulama_baslik.Text = "ŞENKAL APARTMANI YÖNETİMİ";
            this.Uygulama_baslik.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(132, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "DAİRE NO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // daire_No
            // 
            this.daire_No.BackColor = System.Drawing.Color.White;
            this.daire_No.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.daire_No.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.daire_No.FormattingEnabled = true;
            this.daire_No.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.daire_No.Location = new System.Drawing.Point(234, 92);
            this.daire_No.Name = "daire_No";
            this.daire_No.Size = new System.Drawing.Size(192, 27);
            this.daire_No.TabIndex = 3;
            // 
            // bitis_tarihi
            // 
            this.bitis_tarihi.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bitis_tarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.bitis_tarihi.Location = new System.Drawing.Point(234, 172);
            this.bitis_tarihi.Name = "bitis_tarihi";
            this.bitis_tarihi.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bitis_tarihi.Size = new System.Drawing.Size(192, 20);
            this.bitis_tarihi.TabIndex = 4;
            // 
            // baslangıc_tarihi
            // 
            this.baslangıc_tarihi.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.baslangıc_tarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.baslangıc_tarihi.Location = new System.Drawing.Point(234, 136);
            this.baslangıc_tarihi.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.baslangıc_tarihi.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.baslangıc_tarihi.Name = "baslangıc_tarihi";
            this.baslangıc_tarihi.Size = new System.Drawing.Size(192, 20);
            this.baslangıc_tarihi.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(54, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 23);
            this.label2.TabIndex = 6;
            this.label2.Text = "BAŞLANGIÇ TARİHİ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(104, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "BİTİŞ TARİHİ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // access
            // 
            this.access.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.access.Location = new System.Drawing.Point(234, 207);
            this.access.Margin = new System.Windows.Forms.Padding(0);
            this.access.Name = "access";
            this.access.Size = new System.Drawing.Size(192, 30);
            this.access.TabIndex = 10;
            this.access.Text = "SORGULA";
            this.access.UseVisualStyleBackColor = false;
            this.access.Click += new System.EventHandler(this.access_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.SlateBlue;
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listBox1.ForeColor = System.Drawing.Color.White;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(515, 122);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(260, 306);
            this.listBox1.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(570, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 23);
            this.label4.TabIndex = 12;
            this.label4.Text = "BORÇ DÖKÜMÜ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Geri
            // 
            this.Geri.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Geri.Location = new System.Drawing.Point(36, 398);
            this.Geri.Name = "Geri";
            this.Geri.Size = new System.Drawing.Size(192, 30);
            this.Geri.TabIndex = 15;
            this.Geri.Text = "GERİ";
            this.Geri.UseVisualStyleBackColor = true;
            this.Geri.Click += new System.EventHandler(this.Geri_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Geri);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.access);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.baslangıc_tarihi);
            this.Controls.Add(this.bitis_tarihi);
            this.Controls.Add(this.daire_No);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Uygulama_baslik);
            this.DoubleBuffered = true;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "YÖNETİM PANELİ";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Uygulama_baslik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker bitis_tarihi;
        private System.Windows.Forms.DateTimePicker baslangıc_tarihi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button access;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Geri;
        public System.Windows.Forms.ComboBox daire_No;
    }
}