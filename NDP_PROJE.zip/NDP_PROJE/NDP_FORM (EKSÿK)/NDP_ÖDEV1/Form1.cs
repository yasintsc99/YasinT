﻿/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** ÖDEV NUMARASI..........: 1
** ÖĞRENCİ ADI............: YASİN TAŞCI
** ÖĞRENCİ NUMARASI.......: B181200021
** DERSİN ALINDIĞI GRUP...: A
****************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NDP_ÖDEV1
{

    public partial class Form1 : Form
    {
        string accesstype = "";
        Yönetim_Paneli yönetim = new Yönetim_Paneli();
        Daire daire = new Daire("", "");
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Uygulama_baslik.ForeColor = Color.FromArgb(254,4,80);
            lbl_admin.ForeColor = Color.FromArgb(0, 255, 16);
            lbl_kullanıcı.ForeColor = Color.FromArgb(254,161,4);
            lbl_uye.ForeColor = Color.FromArgb(0, 255, 16);
            lbl_sif.ForeColor = Color.FromArgb(254, 161, 4);
            uyarı.Text = "LÜTFEN SİSTEME GİRİŞ YAPMAK İÇİN GİRİŞ TÜRÜNÜZÜ SEÇİNİZ !";
            uyarı.ForeColor = Color.FromArgb(255, 255, 0);
            lbl_kullanıcı.Visible = false;
            lbl_sif.Visible = false;
            textBox_Kullanıcı.Visible=false;
            textBox_sifre.Visible =false;
            access.Text = "GİRİŞ YAP";
            access.ForeColor = Color.FromArgb(254, 4, 80);
            access.BackColor = Color.FromArgb(10, 199, 134);
            access.Visible = false;
            
        }

        private void Btn_uye_Click(object sender, EventArgs e)
        {
            accesstype = "member";
            uyarı.Visible = false;
            Btn_admin.BackColor = Color.Transparent;
            Btn_uye.BackColor = Color.FromArgb(10,199,134);
            lbl_kullanıcı.Text = "KULLANICI ADI :";
            lbl_kullanıcı.Location = new Point(170, 236);
            lbl_kullanıcı.Visible = true;
            lbl_sif.Visible = true;
            textBox_Kullanıcı.Visible = true;
            textBox_sifre.Visible = true;
            if(accesstype.Equals("member"))
            {
                username.ToolTipIcon = ToolTipIcon.Info;
                username.SetToolTip(this.textBox_Kullanıcı, "Kullanıcı adı ad_soyad_daireno şeklinde yazılmalıdır.Örneğin 'Yasin_Taşcı_20'");
                username.AutomaticDelay = 200;
                username.AutoPopDelay = 2000;
                password.SetToolTip(this.textBox_sifre, "Şifreniz T.C Kimlik numaranızın son 6 hanesidir.");
                password.ToolTipIcon = ToolTipIcon.Info;
                password.AutomaticDelay = 200;
                password.AutoPopDelay = 2000;
                access.Visible = true;
            }
        }

        private void Btn_admin_Click(object sender, EventArgs e)
        {
            accesstype = "admin";
            uyarı.Visible = false;
            Btn_uye.BackColor = Color.Transparent;
            Btn_admin.BackColor = Color.FromArgb(10, 199, 134);
            lbl_kullanıcı.Text = "ID :";
            lbl_kullanıcı.Location = new Point(308, 236);
            lbl_kullanıcı.Visible = true;
            lbl_sif.Visible = true;
            textBox_Kullanıcı.Visible = true;
            textBox_sifre.Visible = true;
            if (accesstype.Equals("admin"))
            {
                username.ToolTipIcon = ToolTipIcon.Info;
                username.SetToolTip(this.textBox_Kullanıcı,"");
                username.AutomaticDelay = 200;
                username.AutoPopDelay = 700;
                password.SetToolTip(this.textBox_sifre,"");
                password.ToolTipIcon = ToolTipIcon.Info;
                password.AutomaticDelay = 200;
                password.AutoPopDelay = 600;
                access.Visible = true;
            }        
        }
        private void access_Click(object sender, EventArgs e)
        {
            if(accesstype.Equals("admin"))
            {
                yönetim.Show();
                this.Hide();              
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
