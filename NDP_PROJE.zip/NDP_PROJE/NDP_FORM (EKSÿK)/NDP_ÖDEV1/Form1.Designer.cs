﻿namespace NDP_ÖDEV1
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Uygulama_baslik = new System.Windows.Forms.Label();
            this.Btn_uye = new System.Windows.Forms.Button();
            this.Btn_admin = new System.Windows.Forms.Button();
            this.lbl_admin = new System.Windows.Forms.Label();
            this.lbl_uye = new System.Windows.Forms.Label();
            this.textBox_Kullanıcı = new System.Windows.Forms.TextBox();
            this.lbl_kullanıcı = new System.Windows.Forms.Label();
            this.textBox_sifre = new System.Windows.Forms.TextBox();
            this.lbl_sif = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.ToolTip(this.components);
            this.password = new System.Windows.Forms.ToolTip(this.components);
            this.access = new System.Windows.Forms.Button();
            this.uyarı = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Uygulama_baslik
            // 
            this.Uygulama_baslik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Uygulama_baslik.AutoSize = true;
            this.Uygulama_baslik.BackColor = System.Drawing.Color.Transparent;
            this.Uygulama_baslik.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Uygulama_baslik.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(4)))), ((int)(((byte)(80)))));
            this.Uygulama_baslik.Location = new System.Drawing.Point(234, 29);
            this.Uygulama_baslik.Name = "Uygulama_baslik";
            this.Uygulama_baslik.Size = new System.Drawing.Size(350, 29);
            this.Uygulama_baslik.TabIndex = 0;
            this.Uygulama_baslik.Text = "ŞENKAL APARTMANI YÖNETİMİ";
            this.Uygulama_baslik.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Btn_uye
            // 
            this.Btn_uye.BackColor = System.Drawing.Color.Transparent;
            this.Btn_uye.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_uye.BackgroundImage")));
            this.Btn_uye.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_uye.Location = new System.Drawing.Point(83, 95);
            this.Btn_uye.Name = "Btn_uye";
            this.Btn_uye.Size = new System.Drawing.Size(85, 67);
            this.Btn_uye.TabIndex = 1;
            this.Btn_uye.UseVisualStyleBackColor = false;
            this.Btn_uye.Click += new System.EventHandler(this.Btn_uye_Click);
            // 
            // Btn_admin
            // 
            this.Btn_admin.BackColor = System.Drawing.Color.Transparent;
            this.Btn_admin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_admin.BackgroundImage")));
            this.Btn_admin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_admin.Location = new System.Drawing.Point(395, 95);
            this.Btn_admin.Name = "Btn_admin";
            this.Btn_admin.Size = new System.Drawing.Size(85, 67);
            this.Btn_admin.TabIndex = 2;
            this.Btn_admin.UseVisualStyleBackColor = false;
            this.Btn_admin.Click += new System.EventHandler(this.Btn_admin_Click);
            // 
            // lbl_admin
            // 
            this.lbl_admin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_admin.AutoSize = true;
            this.lbl_admin.BackColor = System.Drawing.Color.Transparent;
            this.lbl_admin.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_admin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(16)))));
            this.lbl_admin.Location = new System.Drawing.Point(515, 118);
            this.lbl_admin.Name = "lbl_admin";
            this.lbl_admin.Size = new System.Drawing.Size(166, 29);
            this.lbl_admin.TabIndex = 3;
            this.lbl_admin.Text = "ADMİN GİRİŞİ";
            this.lbl_admin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbl_uye
            // 
            this.lbl_uye.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_uye.AutoSize = true;
            this.lbl_uye.BackColor = System.Drawing.Color.Transparent;
            this.lbl_uye.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_uye.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(16)))));
            this.lbl_uye.Location = new System.Drawing.Point(194, 118);
            this.lbl_uye.Name = "lbl_uye";
            this.lbl_uye.Size = new System.Drawing.Size(135, 29);
            this.lbl_uye.TabIndex = 4;
            this.lbl_uye.Text = "ÜYE GİRİŞİ";
            this.lbl_uye.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBox_Kullanıcı
            // 
            this.textBox_Kullanıcı.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox_Kullanıcı.Location = new System.Drawing.Point(395, 232);
            this.textBox_Kullanıcı.Name = "textBox_Kullanıcı";
            this.textBox_Kullanıcı.Size = new System.Drawing.Size(149, 33);
            this.textBox_Kullanıcı.TabIndex = 5;
            this.username.SetToolTip(this.textBox_Kullanıcı, "Kullanıcı adı ad_soyad_daireno şeklinde yazılmalıdır.Örneğin \"Yasin_Taşcı_20\"");
            // 
            // lbl_kullanıcı
            // 
            this.lbl_kullanıcı.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_kullanıcı.AutoSize = true;
            this.lbl_kullanıcı.BackColor = System.Drawing.Color.Transparent;
            this.lbl_kullanıcı.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_kullanıcı.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(161)))), ((int)(((byte)(4)))));
            this.lbl_kullanıcı.Location = new System.Drawing.Point(170, 236);
            this.lbl_kullanıcı.Name = "lbl_kullanıcı";
            this.lbl_kullanıcı.Size = new System.Drawing.Size(192, 29);
            this.lbl_kullanıcı.TabIndex = 6;
            this.lbl_kullanıcı.Text = "KULLANICI ADI :";
            this.lbl_kullanıcı.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBox_sifre
            // 
            this.textBox_sifre.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox_sifre.Location = new System.Drawing.Point(395, 298);
            this.textBox_sifre.Name = "textBox_sifre";
            this.textBox_sifre.PasswordChar = '•';
            this.textBox_sifre.Size = new System.Drawing.Size(149, 33);
            this.textBox_sifre.TabIndex = 7;
            // 
            // lbl_sif
            // 
            this.lbl_sif.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_sif.AutoSize = true;
            this.lbl_sif.BackColor = System.Drawing.Color.Transparent;
            this.lbl_sif.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sif.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(161)))), ((int)(((byte)(4)))));
            this.lbl_sif.Location = new System.Drawing.Point(270, 302);
            this.lbl_sif.Name = "lbl_sif";
            this.lbl_sif.Size = new System.Drawing.Size(92, 29);
            this.lbl_sif.TabIndex = 8;
            this.lbl_sif.Text = "ŞİFRE :";
            this.lbl_sif.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // username
            // 
            this.username.AutomaticDelay = 150;
            // 
            // access
            // 
            this.access.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.access.Location = new System.Drawing.Point(395, 366);
            this.access.Margin = new System.Windows.Forms.Padding(0);
            this.access.Name = "access";
            this.access.Size = new System.Drawing.Size(149, 39);
            this.access.TabIndex = 9;
            this.access.Text = "GİRİŞ YAP";
            this.access.UseVisualStyleBackColor = true;
            this.access.Click += new System.EventHandler(this.access_Click);
            // 
            // uyarı
            // 
            this.uyarı.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uyarı.AutoSize = true;
            this.uyarı.BackColor = System.Drawing.Color.Transparent;
            this.uyarı.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.uyarı.Location = new System.Drawing.Point(48, 191);
            this.uyarı.Name = "uyarı";
            this.uyarı.Size = new System.Drawing.Size(82, 29);
            this.uyarı.TabIndex = 10;
            this.uyarı.Text = "MESAJ";
            this.uyarı.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.uyarı);
            this.Controls.Add(this.access);
            this.Controls.Add(this.lbl_sif);
            this.Controls.Add(this.textBox_sifre);
            this.Controls.Add(this.lbl_kullanıcı);
            this.Controls.Add(this.textBox_Kullanıcı);
            this.Controls.Add(this.lbl_uye);
            this.Controls.Add(this.lbl_admin);
            this.Controls.Add(this.Btn_admin);
            this.Controls.Add(this.Btn_uye);
            this.Controls.Add(this.Uygulama_baslik);
            this.DoubleBuffered = true;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ŞENKAL APARTMANI";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Uygulama_baslik;
        private System.Windows.Forms.Button Btn_uye;
        private System.Windows.Forms.Button Btn_admin;
        private System.Windows.Forms.Label lbl_admin;
        private System.Windows.Forms.Label lbl_uye;
        private System.Windows.Forms.TextBox textBox_Kullanıcı;
        private System.Windows.Forms.Label lbl_kullanıcı;
        private System.Windows.Forms.TextBox textBox_sifre;
        private System.Windows.Forms.Label lbl_sif;
        private System.Windows.Forms.ToolTip username;
        private System.Windows.Forms.ToolTip password;
        private System.Windows.Forms.Button access;
        private System.Windows.Forms.Label uyarı;
    }
}

