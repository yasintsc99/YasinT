﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDP_ÖDEV1
{
    public class Daire:Apartman
    {
        private int Borc;
        private int aidat;
        public string daireno;
        public string daire_sahibi;
        public Daire(string DaireNo, string Daire_sahibi)
        {
            daireno = DaireNo;
            daire_sahibi = Daire_sahibi;
        }
        public int AİDAT
        {
            get { return aidat;}
            set { aidat = value;}
        }
        public int BORC
        {
            get { return Borc; }
            set { Borc = value; }
        }
        public int Borc_Goster()
        {
            return Borc;
        }
    }
}
