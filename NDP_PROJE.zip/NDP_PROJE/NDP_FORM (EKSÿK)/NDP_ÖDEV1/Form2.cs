﻿/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** ÖDEV NUMARASI..........: 1
** ÖĞRENCİ ADI............: YASİN TAŞCI
** ÖĞRENCİ NUMARASI.......: B181200021
** DERSİN ALINDIĞI GRUP...: A
****************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NDP_ÖDEV1
{
    public partial class Form2 : Form
    {
        Daire daire1 = new Daire("1", "Kasım Çoban");
        Daire daire2 = new Daire("2", "İlhan Ekşi");
        Daire daire3 = new Daire("3", "Mert Bekir");
        Daire daire4 = new Daire("4", "Ayşe Sabuncu");
        Daire daire5 = new Daire("5", "Ali Beşer");
        Daire daire6 = new Daire("6", "Fatma Şahin");
        Daire daire7 = new Daire("7", "Elif Keleş");
        Daire daire8 = new Daire("8", "Melih Dalyan");
        Daire daire9 = new Daire("9", "Kaan Gürbüz");
        Daire daire10 = new Daire("10", "Kerim Saatçi");
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Uygulama_baslik.ForeColor = Color.FromArgb(254, 4, 80);
            label4.ForeColor = Color.FromArgb(255, 255, 0);
            Geri.ForeColor = Color.FromArgb(254, 4, 80);
            Geri.BackColor = Color.FromArgb(10, 199, 134);
            
        }
        private void access_Click(object sender, EventArgs e)
        {
            TimeSpan tarih_Aralıgı;
            tarih_Aralıgı = DateTime.Parse(baslangıc_tarihi.Text) - DateTime.Parse(bitis_tarihi.Text);
            
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Geri_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Yönetim_Paneli().Show();
        }
    }
}
