﻿/****************************************************************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** ÖDEV NUMARASI..........: 1
** ÖĞRENCİ ADI............: YASİN TAŞCI
** ÖĞRENCİ NUMARASI.......: B181200021
** DERSİN ALINDIĞI GRUP...: A
****************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NDP_ÖDEV1
{
    public partial class Yönetim_Paneli : Form
    {
        Form2 borc_sorgu = new Form2();
        Daire daire1 = new Daire("1", "Kasım Çoban");
        Daire daire2 = new Daire("2", "İlhan Ekşi");
        Daire daire3 = new Daire("3", "Mert Bekir");
        Daire daire4 = new Daire("4", "Ayşe Sabuncu");
        Daire daire5 = new Daire("5", "Ali Beşer");
        Daire daire6 = new Daire("6", "Fatma Şahin");
        Daire daire7 = new Daire("7", "Elif Keleş");
        Daire daire8 = new Daire("8", "Melih Dalyan");
        Daire daire9 = new Daire("9", "Kaan Gürbüz");
        Daire daire10 = new Daire("10", "Kerim Saatçi");
        Daire[] daireler;
        Apartman apartman = new Apartman();
        public Yönetim_Paneli()
        {
            InitializeComponent();
        }
        void Apartman_Olustur()
        {
            daireler[0] = daire1;
            daireler[1] = daire2;
            daireler[2] = daire3;
            daireler[3] = daire4;
            daireler[4] = daire5;
            daireler[5] = daire6;
            daireler[6] = daire7;
            daireler[7] = daire8;
            daireler[8] = daire9;
            daireler[9] = daire10;
            Random random = new Random();
            int ödenen;
            for (int i=0; i<10; i++)
            {            
                ödenen = random.Next(0, 51);
                while (ödenen % 5 != 0) 
                    ödenen = random.Next(0, 51);
                daireler[i].AİDAT = 50;
                apartman.GELİR_EKLE = ödenen;
                daireler[i].BORC = daireler[i].AİDAT - ödenen;
                listBox1.Items.Add(daireler[i].daire_sahibi + "\t" + daireler[i].daireno + "\t" + daireler[i].BORC);
            }
        }
        string choise="";
        void menugizle()
        {
            lbl_dairekayıt.Visible = false;
            hitap.Visible = false;
            lbl_islem.Visible = false;
            daire_kaydı.Visible = false;
            gelir_gider.Visible = false;
            daire_Borc.Visible = false;
            Apart_aidat.Visible = false;
            Gelir.Visible = false;
            Gider.Visible = false;
            seçim.Visible = false;
            Geri.Visible = false;
        }
        void menugoster()
        {
            hitap.Visible = true;
            lbl_islem.Visible = true;
            daire_kaydı.Visible = true;
            gelir_gider.Visible = true;
            daire_Borc.Visible = true;
            Apart_aidat.Visible = true;
            Gelir.Visible = true;
            Gider.Visible = true;
            seçim.Visible = true;
            Geri.Visible = true;
        }
        void KayıtEkranıGizle()
        {
            lbl_dairekayıt.Visible = false;
            lbl_ad.Visible = false;
            lbl_soyad.Visible = false;
            lbl_TCNo.Visible = false;
            lbl_daireNo.Visible = false;
            lbl_kayıt_tarihi.Visible = false;
            textbox_Ad.Visible = false;
            textbox_soyad.Visible = false;
            textbox_TC.Visible = false;
            textbox_daireNo.Visible = false;
            textbox_kayıt.Visible = false;
            Kayıt.Visible = false;
        }
        void KayıtEkranıGoster()
        {
            lbl_dairekayıt.Visible = true;
            lbl_ad.Visible = true;
            lbl_soyad.Visible = true;
            lbl_TCNo.Visible = true;
            lbl_daireNo.Visible = true;
            lbl_kayıt_tarihi.Visible = true;
            textbox_Ad.Visible = true;
            textbox_soyad.Visible = true;
            textbox_TC.Visible = true;
            textbox_daireNo.Visible = true;
            textbox_kayıt.Visible = true;
            Kayıt.Visible = true;
        }
        private void Yönetim_Paneli_Load(object sender, EventArgs e)
        {
            KayıtEkranıGizle();
            listBox1.Items.Add("DAİRE SAHİBİ\tDAİRE NO\tBORÇ TUTARI");           
            Uygulama_baslik.ForeColor = Color.FromArgb(254, 4, 80);
            hitap.ForeColor = Color.FromArgb(0, 255, 16);
            seçim.ForeColor = Color.FromArgb(254, 4, 80);
            seçim.BackColor = Color.FromArgb(10, 199, 134);
            Geri.ForeColor = Color.FromArgb(254, 4, 80);
            Geri.BackColor = Color.FromArgb(10, 199, 134);
            Kayıt.ForeColor = Color.FromArgb(254, 4, 80);
            Kayıt.BackColor = Color.FromArgb(10, 199, 134);
            lbl_dairekayıt.ForeColor = Color.FromArgb(10, 199, 134);
            
        }

        private void daire_kaydı_CheckedChanged(object sender, EventArgs e)
        {
            choise = "daire_kaydı";
        }

        private void gelir_gider_CheckedChanged(object sender, EventArgs e)
        {
            choise = "gelir_gider";
        }

        private void daire_Borc_CheckedChanged(object sender, EventArgs e)
        {
            choise = "daire_borc";
        }

        private void Apart_aidat_CheckedChanged(object sender, EventArgs e)
        {
            choise = "aidat_takip";
        }

        private void Gelir_CheckedChanged(object sender, EventArgs e)
        {
            choise = "gelir";
        }

        private void Gider_CheckedChanged(object sender, EventArgs e)
        {
            choise = "gelir";
        }

        private void seçim_Click(object sender, EventArgs e)
        {
            if(!choise.Equals(""))
            {
                menugizle();
            }
            if (choise.Equals("daire_borc"))
            {
                borc_sorgu.Show();
                this.Hide();
            }
            else if(choise.Equals("daire_kaydı"))
            {
                menugizle();
                KayıtEkranıGoster();                       
            }
            else if(choise.Equals("aidat_takip"))
            {
                menugizle();
                KayıtEkranıGizle();
                Apartman_Olustur();
            }
        }

        private void Geri_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form1().Show();
        }

        private void Yönetim_Paneli_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void TextBox_Ad_KeyPress(object sender, KeyPressEventArgs e)
        {
            textbox_Ad.MaxLength = 20;
            if (char.IsDigit(e.KeyChar))
                e.Handled = true;           
        }

        private void textbox_soyad_KeyPress(object sender, KeyPressEventArgs e)
        {
            textbox_soyad.MaxLength = 20;
            if (char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void textbox_TC_KeyPress(object sender, KeyPressEventArgs e)
        {
            textbox_TC.MaxLength = 11;
            if (char.IsLetter(e.KeyChar))
                e.Handled = true;
               
        }

        private void textbox_daireNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            textbox_daireNo.MaxLength = 2;
            if (char.IsLetter(e.KeyChar))
                e.Handled = true;
        }
        private void Kayıt_Click(object sender, EventArgs e)
        {
            borc_sorgu.daire_No.Items.Add(textbox_daireNo.Text);
            borc_sorgu.Show();
            this.Hide();
        }
    }
}
