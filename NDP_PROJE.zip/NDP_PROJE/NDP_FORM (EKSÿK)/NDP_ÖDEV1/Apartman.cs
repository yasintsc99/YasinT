﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDP_ÖDEV1
{
    public class Apartman
    {
        private int Gider;
        private int Gelir;
        public int GİDER_EKLE
        {
            get { return Gider; }
            set { Gider += value;}
        }
        public int GELİR_EKLE
        {
            get { return Gelir; }
            set { Gelir += value; }
        }
        public int Apartman_Durumu()
        {
            return (Gelir - Gider);
        }
    }
}
