﻿namespace NDP_ÖDEV1
{
    partial class Yönetim_Paneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Yönetim_Paneli));
            this.Uygulama_baslik = new System.Windows.Forms.Label();
            this.hitap = new System.Windows.Forms.Label();
            this.lbl_islem = new System.Windows.Forms.Label();
            this.daire_kaydı = new System.Windows.Forms.RadioButton();
            this.gelir_gider = new System.Windows.Forms.RadioButton();
            this.daire_Borc = new System.Windows.Forms.RadioButton();
            this.seçim = new System.Windows.Forms.Button();
            this.Apart_aidat = new System.Windows.Forms.RadioButton();
            this.Gelir = new System.Windows.Forms.RadioButton();
            this.Gider = new System.Windows.Forms.RadioButton();
            this.lbl_dairekayıt = new System.Windows.Forms.Label();
            this.Geri = new System.Windows.Forms.Button();
            this.lbl_ad = new System.Windows.Forms.Label();
            this.lbl_soyad = new System.Windows.Forms.Label();
            this.textbox_Ad = new System.Windows.Forms.TextBox();
            this.textbox_soyad = new System.Windows.Forms.TextBox();
            this.lbl_TCNo = new System.Windows.Forms.Label();
            this.textbox_TC = new System.Windows.Forms.TextBox();
            this.lbl_daireNo = new System.Windows.Forms.Label();
            this.textbox_daireNo = new System.Windows.Forms.TextBox();
            this.Kayıt = new System.Windows.Forms.Button();
            this.lbl_kayıt_tarihi = new System.Windows.Forms.Label();
            this.textbox_kayıt = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Uygulama_baslik
            // 
            this.Uygulama_baslik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Uygulama_baslik.AutoSize = true;
            this.Uygulama_baslik.BackColor = System.Drawing.Color.Transparent;
            this.Uygulama_baslik.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Uygulama_baslik.Location = new System.Drawing.Point(234, 29);
            this.Uygulama_baslik.Name = "Uygulama_baslik";
            this.Uygulama_baslik.Size = new System.Drawing.Size(350, 29);
            this.Uygulama_baslik.TabIndex = 2;
            this.Uygulama_baslik.Text = "ŞENKAL APARTMANI YÖNETİMİ";
            this.Uygulama_baslik.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // hitap
            // 
            this.hitap.AutoSize = true;
            this.hitap.BackColor = System.Drawing.Color.Transparent;
            this.hitap.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.hitap.Location = new System.Drawing.Point(61, 85);
            this.hitap.Name = "hitap";
            this.hitap.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hitap.Size = new System.Drawing.Size(293, 23);
            this.hitap.TabIndex = 3;
            this.hitap.Text = "HOŞGELDİNİZ SAYIN YÖNETİCİ ;";
            // 
            // lbl_islem
            // 
            this.lbl_islem.AutoSize = true;
            this.lbl_islem.BackColor = System.Drawing.Color.Transparent;
            this.lbl_islem.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_islem.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_islem.Location = new System.Drawing.Point(61, 126);
            this.lbl_islem.Name = "lbl_islem";
            this.lbl_islem.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_islem.Size = new System.Drawing.Size(543, 23);
            this.lbl_islem.TabIndex = 4;
            this.lbl_islem.Text = "LÜTFEN İŞLEM MENÜSÜNDEN İSTEDİĞİNİZ İŞLEMİ SEÇİNİZ...";
            // 
            // daire_kaydı
            // 
            this.daire_kaydı.AutoSize = true;
            this.daire_kaydı.BackColor = System.Drawing.Color.Transparent;
            this.daire_kaydı.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.daire_kaydı.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.daire_kaydı.Location = new System.Drawing.Point(65, 168);
            this.daire_kaydı.Name = "daire_kaydı";
            this.daire_kaydı.Size = new System.Drawing.Size(123, 27);
            this.daire_kaydı.TabIndex = 5;
            this.daire_kaydı.Text = "Daire Kaydı";
            this.daire_kaydı.UseVisualStyleBackColor = false;
            this.daire_kaydı.CheckedChanged += new System.EventHandler(this.daire_kaydı_CheckedChanged);
            // 
            // gelir_gider
            // 
            this.gelir_gider.AutoSize = true;
            this.gelir_gider.BackColor = System.Drawing.Color.Transparent;
            this.gelir_gider.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gelir_gider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gelir_gider.Location = new System.Drawing.Point(65, 201);
            this.gelir_gider.Name = "gelir_gider";
            this.gelir_gider.Size = new System.Drawing.Size(205, 27);
            this.gelir_gider.TabIndex = 6;
            this.gelir_gider.Text = "Gelir - Gider Durumu";
            this.gelir_gider.UseVisualStyleBackColor = false;
            this.gelir_gider.CheckedChanged += new System.EventHandler(this.gelir_gider_CheckedChanged);
            // 
            // daire_Borc
            // 
            this.daire_Borc.AutoSize = true;
            this.daire_Borc.BackColor = System.Drawing.Color.Transparent;
            this.daire_Borc.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.daire_Borc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.daire_Borc.Location = new System.Drawing.Point(65, 234);
            this.daire_Borc.Name = "daire_Borc";
            this.daire_Borc.Size = new System.Drawing.Size(222, 27);
            this.daire_Borc.TabIndex = 7;
            this.daire_Borc.Text = "Daire Borcu Sorgulama";
            this.daire_Borc.UseVisualStyleBackColor = false;
            this.daire_Borc.CheckedChanged += new System.EventHandler(this.daire_Borc_CheckedChanged);
            // 
            // seçim
            // 
            this.seçim.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.seçim.Location = new System.Drawing.Point(65, 382);
            this.seçim.Name = "seçim";
            this.seçim.Size = new System.Drawing.Size(170, 31);
            this.seçim.TabIndex = 8;
            this.seçim.Text = "SEÇ";
            this.seçim.UseVisualStyleBackColor = true;
            this.seçim.Click += new System.EventHandler(this.seçim_Click);
            // 
            // Apart_aidat
            // 
            this.Apart_aidat.AutoSize = true;
            this.Apart_aidat.BackColor = System.Drawing.Color.Transparent;
            this.Apart_aidat.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Apart_aidat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Apart_aidat.Location = new System.Drawing.Point(65, 269);
            this.Apart_aidat.Name = "Apart_aidat";
            this.Apart_aidat.Size = new System.Drawing.Size(213, 27);
            this.Apart_aidat.TabIndex = 9;
            this.Apart_aidat.Text = "Apartman Aidat Takibi";
            this.Apart_aidat.UseVisualStyleBackColor = false;
            this.Apart_aidat.CheckedChanged += new System.EventHandler(this.Apart_aidat_CheckedChanged);
            // 
            // Gelir
            // 
            this.Gelir.AutoSize = true;
            this.Gelir.BackColor = System.Drawing.Color.Transparent;
            this.Gelir.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Gelir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Gelir.Location = new System.Drawing.Point(65, 302);
            this.Gelir.Name = "Gelir";
            this.Gelir.Size = new System.Drawing.Size(112, 27);
            this.Gelir.TabIndex = 10;
            this.Gelir.Text = "Gelir Girişi";
            this.Gelir.UseVisualStyleBackColor = false;
            this.Gelir.CheckedChanged += new System.EventHandler(this.Gelir_CheckedChanged);
            // 
            // Gider
            // 
            this.Gider.AutoSize = true;
            this.Gider.BackColor = System.Drawing.Color.Transparent;
            this.Gider.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Gider.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Gider.Location = new System.Drawing.Point(65, 335);
            this.Gider.Name = "Gider";
            this.Gider.Size = new System.Drawing.Size(119, 27);
            this.Gider.TabIndex = 11;
            this.Gider.Text = "Gider Girişi";
            this.Gider.UseVisualStyleBackColor = false;
            this.Gider.CheckedChanged += new System.EventHandler(this.Gider_CheckedChanged);
            // 
            // lbl_dairekayıt
            // 
            this.lbl_dairekayıt.AutoSize = true;
            this.lbl_dairekayıt.BackColor = System.Drawing.Color.Transparent;
            this.lbl_dairekayıt.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_dairekayıt.Location = new System.Drawing.Point(59, 85);
            this.lbl_dairekayıt.Name = "lbl_dairekayıt";
            this.lbl_dairekayıt.Size = new System.Drawing.Size(138, 25);
            this.lbl_dairekayıt.TabIndex = 13;
            this.lbl_dairekayıt.Text = "DAİRE KAYDI";
            // 
            // Geri
            // 
            this.Geri.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Geri.Location = new System.Drawing.Point(565, 382);
            this.Geri.Name = "Geri";
            this.Geri.Size = new System.Drawing.Size(170, 31);
            this.Geri.TabIndex = 14;
            this.Geri.Text = "GERİ";
            this.Geri.UseVisualStyleBackColor = true;
            this.Geri.Click += new System.EventHandler(this.Geri_Click);
            // 
            // lbl_ad
            // 
            this.lbl_ad.AutoSize = true;
            this.lbl_ad.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ad.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_ad.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_ad.Location = new System.Drawing.Point(61, 145);
            this.lbl_ad.Name = "lbl_ad";
            this.lbl_ad.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_ad.Size = new System.Drawing.Size(34, 23);
            this.lbl_ad.TabIndex = 15;
            this.lbl_ad.Text = "AD";
            // 
            // lbl_soyad
            // 
            this.lbl_soyad.AutoSize = true;
            this.lbl_soyad.BackColor = System.Drawing.Color.Transparent;
            this.lbl_soyad.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_soyad.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_soyad.Location = new System.Drawing.Point(61, 198);
            this.lbl_soyad.Name = "lbl_soyad";
            this.lbl_soyad.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_soyad.Size = new System.Drawing.Size(69, 23);
            this.lbl_soyad.TabIndex = 16;
            this.lbl_soyad.Text = "SOYAD";
            // 
            // textbox_Ad
            // 
            this.textbox_Ad.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textbox_Ad.Location = new System.Drawing.Point(194, 145);
            this.textbox_Ad.Name = "textbox_Ad";
            this.textbox_Ad.Size = new System.Drawing.Size(160, 23);
            this.textbox_Ad.TabIndex = 17;
            this.textbox_Ad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_Ad_KeyPress);
            // 
            // textbox_soyad
            // 
            this.textbox_soyad.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textbox_soyad.Location = new System.Drawing.Point(194, 198);
            this.textbox_soyad.Name = "textbox_soyad";
            this.textbox_soyad.Size = new System.Drawing.Size(160, 23);
            this.textbox_soyad.TabIndex = 18;
            this.textbox_soyad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textbox_soyad_KeyPress);
            // 
            // lbl_TCNo
            // 
            this.lbl_TCNo.AutoSize = true;
            this.lbl_TCNo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_TCNo.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_TCNo.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_TCNo.Location = new System.Drawing.Point(61, 248);
            this.lbl_TCNo.Name = "lbl_TCNo";
            this.lbl_TCNo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_TCNo.Size = new System.Drawing.Size(64, 23);
            this.lbl_TCNo.TabIndex = 19;
            this.lbl_TCNo.Text = "TC NO";
            // 
            // textbox_TC
            // 
            this.textbox_TC.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textbox_TC.Location = new System.Drawing.Point(194, 248);
            this.textbox_TC.Name = "textbox_TC";
            this.textbox_TC.Size = new System.Drawing.Size(160, 23);
            this.textbox_TC.TabIndex = 20;
            this.textbox_TC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textbox_TC_KeyPress);
            // 
            // lbl_daireNo
            // 
            this.lbl_daireNo.AutoSize = true;
            this.lbl_daireNo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_daireNo.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_daireNo.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_daireNo.Location = new System.Drawing.Point(61, 295);
            this.lbl_daireNo.Name = "lbl_daireNo";
            this.lbl_daireNo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_daireNo.Size = new System.Drawing.Size(96, 23);
            this.lbl_daireNo.TabIndex = 21;
            this.lbl_daireNo.Text = "DAİRE NO";
            // 
            // textbox_daireNo
            // 
            this.textbox_daireNo.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textbox_daireNo.Location = new System.Drawing.Point(194, 295);
            this.textbox_daireNo.Name = "textbox_daireNo";
            this.textbox_daireNo.Size = new System.Drawing.Size(160, 23);
            this.textbox_daireNo.TabIndex = 22;
            this.textbox_daireNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textbox_daireNo_KeyPress);
            // 
            // Kayıt
            // 
            this.Kayıt.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Kayıt.Location = new System.Drawing.Point(194, 394);
            this.Kayıt.Name = "Kayıt";
            this.Kayıt.Size = new System.Drawing.Size(157, 31);
            this.Kayıt.TabIndex = 23;
            this.Kayıt.Text = "KAYDET";
            this.Kayıt.UseVisualStyleBackColor = true;
            this.Kayıt.Click += new System.EventHandler(this.Kayıt_Click);
            // 
            // lbl_kayıt_tarihi
            // 
            this.lbl_kayıt_tarihi.AutoSize = true;
            this.lbl_kayıt_tarihi.BackColor = System.Drawing.Color.Transparent;
            this.lbl_kayıt_tarihi.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_kayıt_tarihi.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_kayıt_tarihi.Location = new System.Drawing.Point(60, 343);
            this.lbl_kayıt_tarihi.Name = "lbl_kayıt_tarihi";
            this.lbl_kayıt_tarihi.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_kayıt_tarihi.Size = new System.Drawing.Size(128, 23);
            this.lbl_kayıt_tarihi.TabIndex = 24;
            this.lbl_kayıt_tarihi.Text = "KAYIT TARİHİ";
            // 
            // textbox_kayıt
            // 
            this.textbox_kayıt.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textbox_kayıt.Location = new System.Drawing.Point(194, 343);
            this.textbox_kayıt.Name = "textbox_kayıt";
            this.textbox_kayıt.Size = new System.Drawing.Size(160, 23);
            this.textbox_kayıt.TabIndex = 25;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.SlateBlue;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(147, 102);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(473, 264);
            this.listBox1.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(263, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 25);
            this.label1.TabIndex = 27;
            this.label1.Text = "APARTMAN AİDAT TAKİBİ";
            // 
            // Yönetim_Paneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textbox_kayıt);
            this.Controls.Add(this.lbl_kayıt_tarihi);
            this.Controls.Add(this.Kayıt);
            this.Controls.Add(this.textbox_daireNo);
            this.Controls.Add(this.lbl_daireNo);
            this.Controls.Add(this.textbox_TC);
            this.Controls.Add(this.lbl_TCNo);
            this.Controls.Add(this.textbox_soyad);
            this.Controls.Add(this.textbox_Ad);
            this.Controls.Add(this.lbl_soyad);
            this.Controls.Add(this.lbl_ad);
            this.Controls.Add(this.Geri);
            this.Controls.Add(this.lbl_dairekayıt);
            this.Controls.Add(this.Gider);
            this.Controls.Add(this.Gelir);
            this.Controls.Add(this.Apart_aidat);
            this.Controls.Add(this.seçim);
            this.Controls.Add(this.daire_Borc);
            this.Controls.Add(this.gelir_gider);
            this.Controls.Add(this.daire_kaydı);
            this.Controls.Add(this.lbl_islem);
            this.Controls.Add(this.hitap);
            this.Controls.Add(this.Uygulama_baslik);
            this.DoubleBuffered = true;
            this.Name = "Yönetim_Paneli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yönetim_Paneli";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Yönetim_Paneli_FormClosed);
            this.Load += new System.EventHandler(this.Yönetim_Paneli_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Uygulama_baslik;
        private System.Windows.Forms.Label hitap;
        private System.Windows.Forms.Label lbl_islem;
        private System.Windows.Forms.RadioButton daire_kaydı;
        private System.Windows.Forms.RadioButton gelir_gider;
        private System.Windows.Forms.RadioButton daire_Borc;
        private System.Windows.Forms.Button seçim;
        private System.Windows.Forms.RadioButton Apart_aidat;
        private System.Windows.Forms.RadioButton Gelir;
        private System.Windows.Forms.RadioButton Gider;
        private System.Windows.Forms.Label lbl_dairekayıt;
        private System.Windows.Forms.Button Geri;
        private System.Windows.Forms.Label lbl_ad;
        private System.Windows.Forms.Label lbl_soyad;
        private System.Windows.Forms.TextBox textbox_Ad;
        private System.Windows.Forms.TextBox textbox_soyad;
        private System.Windows.Forms.Label lbl_TCNo;
        private System.Windows.Forms.TextBox textbox_TC;
        private System.Windows.Forms.Label lbl_daireNo;
        private System.Windows.Forms.Button Kayıt;
        private System.Windows.Forms.Label lbl_kayıt_tarihi;
        private System.Windows.Forms.TextBox textbox_kayıt;
        public System.Windows.Forms.TextBox textbox_daireNo;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
    }
}